import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { FeaturedContent } from "./components/FeaturedContent";
import { Testimonials } from "./components/Testimonials";
import { Newsletter } from "./components/Newsletter";
import { LiveChat } from "./components/LiveChat";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-black">
      <Header />
      <main>
        <Hero />
        <FeaturedContent />
        <Testimonials />
        <Newsletter />
      </main>
      <Footer />
      <LiveChat />
    </div>
  );
}
