import { Mail, Send } from "lucide-react";
import { useState } from "react";

export function Newsletter() {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      console.log("Newsletter signup:", email);
      setIsSubmitted(true);
      setTimeout(() => {
        setEmail("");
        setIsSubmitted(false);
      }, 3000);
    }
  };

  return (
    <section id="newsletter" className="bg-gradient-to-r from-red-600 to-purple-600 py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-full mb-4">
            <Mail className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-white mb-4">Stay Updated</h2>
          <p className="text-white/90">
            Subscribe to our newsletter and never miss new releases, exclusive content, and special offers
          </p>
        </div>

        <form onSubmit={handleSubmit} className="max-w-md mx-auto">
          <div className="flex gap-2">
            <input
              type="email"
              placeholder="Enter your email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="flex-1 px-6 py-3 rounded-lg bg-white text-gray-900 placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-white"
            />
            <button
              type="submit"
              className="bg-black hover:bg-gray-900 text-white px-6 py-3 rounded-lg flex items-center gap-2 transition-colors"
            >
              <Send className="w-5 h-5" />
              <span className="hidden sm:inline">Subscribe</span>
            </button>
          </div>
          {isSubmitted && (
            <p className="text-white text-center mt-4">
              ✓ Thank you for subscribing!
            </p>
          )}
        </form>
      </div>
    </section>
  );
}
