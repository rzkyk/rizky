import { Star } from "lucide-react";

const testimonials = [
  {
    id: 1,
    name: "Rahmat",
    role: "Movie Enthusiast",
    rating: 5,
    text: "StreamVibe has completely changed how I watch entertainment. The selection is incredible and the streaming quality is flawless!",
  },
  {
    id: 2,
    name: "Beni",
    role: "Family Subscriber",
    rating: 5,
    text: "Perfect for the whole family! We love the variety of content and the user-friendly interface. Worth every penny.",
  },
  {
    id: 3,
    name: "Danu",
    role: "Series Binger",
    rating: 5,
    text: "I've tried many streaming platforms, but StreamVibe stands out. Original content is amazing and updates are frequent!",
  },
];

export function Testimonials() {
  return (
    <section id="testimonials" className="bg-black py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-white mb-4">What Our Users Say</h2>
          <p className="text-gray-400">
            Join thousands of satisfied streamers worldwide
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.id}
              className="bg-gray-900 p-6 rounded-lg border border-gray-800 hover:border-red-600 transition-colors"
            >
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-yellow-500 text-yellow-500" />
                ))}
              </div>
              <p className="text-gray-300 mb-6">
                "{testimonial.text}"
              </p>
              <div>
                <p className="text-white">{testimonial.name}</p>
                <p className="text-gray-500 text-sm">{testimonial.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}