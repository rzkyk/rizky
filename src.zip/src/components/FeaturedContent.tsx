import { ImageWithFallback } from "./figma/ImageWithFallback";

const featuredItems = [
  {
    id: 1,
    title: "Action Thrillers",
    image: "https://images.unsplash.com/photo-1645808651017-c5e3018553c7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY3Rpb24lMjBtb3ZpZSUyMHNjZW5lfGVufDF8fHx8MTc2NDc4MTM0M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Movies",
  },
  {
    id: 2,
    title: "Cinema Experience",
    image: "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaW5lbWElMjB3YXRjaGluZyUyMGZpbG18ZW58MXx8fHwxNzY0ODQwNjEwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Featured",
  },
  {
    id: 3,
    title: "Original Series",
    image: "https://images.unsplash.com/photo-1558886668-e9a014c0141a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0diUyMHNob3clMjBwcm9kdWN0aW9ufGVufDF8fHx8MTc2NDc4OTUxNnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Series",
  },
  {
    id: 4,
    title: "Nature Documentaries",
    image: "https://images.unsplash.com/photo-1603016129004-c7539f86b53f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N1bWVudGFyeSUyMG5hdHVyZXxlbnwxfHx8fDE3NjQ4NDA2MTF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Documentaries",
  },
];

export function FeaturedContent() {
  return (
    <section id="movies" className="bg-gray-900 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-white mb-2">Featured Content</h2>
            <p className="text-gray-400">
              Explore our handpicked selection of the best movies and series
            </p>
          </div>
          <a href="#browse" className="text-red-600 hover:text-red-500 transition-colors">
            View All →
          </a>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredItems.map((item) => (
            <a
              key={item.id}
              href={`#content-${item.id}`}
              className="group relative rounded-lg overflow-hidden aspect-[2/3] cursor-pointer"
            >
              <ImageWithFallback
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <span className="text-red-600 text-sm">{item.category}</span>
                  <h3 className="text-white mt-1">{item.title}</h3>
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
